import java.util.Scanner;
import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;

public class ATMMachine {

    private static final String url = "jdbc:mysql://localhost:3306/bank_app";
    private static final String user = "bank_app";
    private static final String pass = "Sarthak@123";
   
    private int balance = 0;
    private Scanner sc = new Scanner(System.in);
    private int wit;
    private long accountNumber;

    public void Welcome(){
        System.out.println("Welcome to Sarthak's ATM, how may I help you.\n");
    }

    public void option(){
       System.out.println("Press 1 if you want to login.");
       System.out.println("Press 2 if you want to create a new account.");
       
       int opt = sc.nextInt();

       switch(opt){
        case 1:
            Acc_details();
            break;
        case 2:
            System.out.println("Enter password :");
            String password = sc.next();
            System.out.println("Enter initial balance :");
            double initialBalnce = sc.nextDouble();
            createUserAccount(password, initialBalnce);

            System.out.println("Account created successfully.");
            System.exit(0);
       }
    }

    public void Acc_details(){

        System.out.println("Enter account number :");
        accountNumber = sc.nextLong();

        System.out.println("Enter password :");
        String enteredPassword = sc.next();

        try(Connection connection = DataBaseConnection.getConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT Acc_Pass, balance FROM account_details WHERE Acc_No = ?")){
            
            statement.setString(1, String.valueOf(accountNumber));            
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()){

                String hashedPasswordFromDB = resultSet.getString("Acc_Pass");
                balance = resultSet.getInt("balance");

                if(BCrypt.checkpw(enteredPassword, hashedPasswordFromDB)){

                    System.out.println("Welcome User "+accountNumber);
                }
                else{
                    System.out.println("Invalid password");
                }
            }
            else{
                System.out.println("Invalid account number");
                Acc_details();
            }
        }
            catch (SQLException e){
               
                System.out.println("Error Accessing DataBase" + e.getMessage());
                e.printStackTrace();
            }
        }


    public void Operations(){

        int choice;
        System.out.println("Press 1 to check account balance.");
        System.out.println("Press 2 to withdraw money.");
        System.out.println("Press 3 to deposite money.");
        System.out.println("Press 4 to exit.");

        System.out.println("Enter your choice.");
        choice = sc.nextInt();

        switch (choice) {

            case 1:
                Balance();
                break;
            
            case 2:
                Withdraw();
                break;
            
            case 3:
                Deposit();
                break;
            
            case 4:
                sc.close();
                System.exit(0);
                break;
        
            default:
                System.out.println("Invalid Choice");
                Operations();
        }
    }

    public void Repeat(){

        clearScreen();

        int choice;

        System.out.println("If you want to continue press 1 else press 0 to exit.");
        choice = sc.nextInt();

        switch (choice) {
            case 1:
                Operations();
                break;

            case 0:
                sc.close();
                System.exit(0);

            default :
                System.out.println("Invalid choice.");
                System.out.println("Please choose between 0 and 1");
                Repeat();
                break;
        }
    }

    public boolean createUserAccount(String password, double initialBalance) {
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());  // Hash the password
    
        // SQL query to insert new user with auto-incrementing account number
        String sql = "INSERT INTO account_details (Acc_pass, Balance) VALUES (?, ?)";
    
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
    
            // Set the hashed password and initial balance
            stmt.setString(1, hashedPassword);  // Use the hashed password
            stmt.setDouble(2, initialBalance);  // The initial balance entered by the user
    
            // Execute the query and check if rows were inserted
            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;  // Returns true if the account is successfully created
    
        } catch (SQLException e) {
            System.out.println("Error creating user: " + e.getMessage());
            return false;
        }
    }
    

    public void Balance(){
            
        System.out.println("Balance :"+balance);
    }

    public void Withdraw(){

        System.out.println("Enter the amount you want to withdraw :");
        wit = sc.nextInt();
        
        if(wit < 0){

            System.out.println("Invalid amount !!!");
            Withdraw();
        }
        else if(wit > balance){
            System.out.println("Insufficient Balance!!!");
            Repeat();
            return;
        }
        else{

            balance -= wit;

            try (Connection connection = DataBaseConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement("UPDATE account_details SET Balance = ? WHERE Acc_no = ?")){
                
                statement.setInt(1, balance);
                statement.setLong(2,accountNumber);
                statement.executeUpdate();

            } catch (SQLException e) {
                
                System.out.println("Error Updating balance "+e.getMessage());
            }

            System.out.println("Balance :"+balance);
            Repeat();
        }
    }

    public void Deposit(){

        int dip;

        System.out.println("Enter the amount you want to deposit.");
        dip = sc.nextInt();

        if(dip<100){

            System.out.println("Minimum deposit amount must be greater than or equal to 100.");
            Deposit();
            return;
        }
        else{
            balance += dip;
            try (Connection connection = DataBaseConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement("UPDATE account_details SET balance = ? WHERE Acc_no = ?")){
                
                statement.setInt(1, balance);
                statement.setLong(2,accountNumber);;
                statement.executeUpdate();

            } catch (Exception e) {
                
                System.out.println("Error updating balance "+e.getMessage());
            }
        }

        System.out.println("Balance :"+balance);
        Repeat();
    }

    public void clearScreen() {  
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }

    public static void main(String[] args) {

        ATMMachine atm = new ATMMachine();
        atm.Welcome();
        try{
           atm.option();
        }  catch(Exception e){
            System.out.println("Error During account details "+e.getMessage());
        }
        try{
            atm.Operations();
        }  catch(Exception e){
            System.out.println("Error During account details "+e.getMessage());
        }
        atm.Repeat();
    }
}
class DataBaseConnection {
    private static final String url = "jdbc:mysql://localhost:3306/bank_app";
    private static final String user = "bank_app";
    private static final String password = "Sarthak@123";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC Driver not found", e);
        }
    }
}